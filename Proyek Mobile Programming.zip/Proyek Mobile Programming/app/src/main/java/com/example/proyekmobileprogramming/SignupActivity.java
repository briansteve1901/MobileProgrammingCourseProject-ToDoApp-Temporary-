package com.example.proyekmobileprogramming;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignupActivity extends Activity {

    private FirebaseAuth mAuth;
    private TextView emailTxt;
    private TextView passTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        mAuth = FirebaseAuth.getInstance();
        emailTxt = findViewById(R.id.signup_email);
        passTxt = findViewById(R.id.signup_password);

    }

    public void signUpNewUser(View view){
            String email = emailTxt.getText().toString();
            String pass = passTxt.getText().toString();
            if(email.isEmpty() || pass.isEmpty()){
                Toast.makeText(this, "Please Insert Your Email or Password", Toast.LENGTH_SHORT).show();
                return;
            }
            createAccount(email, pass);
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            startActivity(new Intent(SignupActivity.this, MainActivity.class));
        }
    }

    public void createAccount(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("Firebase Sign Up", "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(SignupActivity.this, "Sign Up success.", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(SignupActivity.this, MainActivity.class));
                        } else {
                            Log.w("Firebase Sign Up", "createUserWithEmail:failure", task.getException());
                            Toast.makeText(SignupActivity.this, "Sign Up failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

}