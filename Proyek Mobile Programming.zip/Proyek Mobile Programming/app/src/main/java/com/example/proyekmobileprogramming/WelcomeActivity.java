package com.example.proyekmobileprogramming;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class WelcomeActivity extends Activity {

    TextView logIn_text;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        logIn_text = findViewById(R.id.welcome_logInText);
        makeClickAbleText(logIn_text);

    }

    public void goToSignUp(View view){
        Intent signUpIntent = new Intent(WelcomeActivity.this, SignupActivity.class);
        startActivity(signUpIntent);
    }

    public void makeClickAbleText(TextView textView){
        String txt = "Already has an account? Log In";
        SpannableString ss = new SpannableString(txt);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {
               startActivity(new Intent(WelcomeActivity.this, LoginActivity.class));
            }
        };

        ss.setSpan(clickableSpan,24,30, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());

    }
}
