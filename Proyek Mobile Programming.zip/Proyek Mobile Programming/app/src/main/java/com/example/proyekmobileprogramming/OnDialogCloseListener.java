package com.example.proyekmobileprogramming;

import android.content.DialogInterface;

public interface OnDialogCloseListener {

    void onDialogClose(DialogInterface dialogInterface);
}
